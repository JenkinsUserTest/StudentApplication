package com.yash.client;

import java.nio.charset.Charset;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.web.client.RestTemplate;

import com.yash.handler.StudentErrorHandler;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;

public class PostStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestTemplate template=new RestTemplate();
		
		
		template.setErrorHandler(new StudentErrorHandler());
		
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(323322);
		studentRequest.setStudentName("yyyyy");
		studentRequest.setStudentAddress("Amanora");
		
		HttpHeaders headers=new HttpHeaders();
	   	String auth = "admin" + ":" + "admin123";
			   byte[] encodedAuth = Base64.encode( 
			           auth.getBytes(Charset.forName("US-ASCII")) );
			        String authHeader = "Basic " + new String( encodedAuth );
			        headers.add("Authorization", authHeader);
		        headers.setContentType(MediaType.APPLICATION_JSON);
		        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		        requestFactory.setOutputStreaming(false);
		        template.setRequestFactory(requestFactory);
		       
		HttpEntity<StudentRequest> requestEntity =new HttpEntity<StudentRequest>(studentRequest,headers);
		String url="http://localhost:8082/student-app/students";
		
		StudentRegisteredResponse response=
				template.postForObject(url,requestEntity ,StudentRegisteredResponse.class);
		
		System.out.println("Message:"+response.getResponseMessage());
	
	
		
		
		

	}

}
