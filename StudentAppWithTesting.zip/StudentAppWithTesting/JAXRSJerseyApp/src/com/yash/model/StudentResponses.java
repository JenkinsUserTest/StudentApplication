package com.yash.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class StudentResponses {
	private List<StudentResponse> studentResponse;
	
	private DepartmentResponse departmentResponse;
	public List<StudentResponse> getStudentResponse() {
		return studentResponse;
	}
	public void setStudentResponse(List<StudentResponse> studentResponse) {
		this.studentResponse = studentResponse;
	}
	public DepartmentResponse getDepartmentResponse() {
		return departmentResponse;
	}
	public void setDepartmentResponse(DepartmentResponse departmentResponse) {
		this.departmentResponse = departmentResponse;
	}
	
	
}
