package com.yash.factory;

import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.dao.StudentDAO;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;

public class FactoryStudent {
	
	public static StudentDAO createStudentDAO() {
		StudentDAO studentDAO=new JDBCStudentDAOImpl();
		return studentDAO;
	}
	
	public static StudentService createStudentService() {
		StudentService studentService=new StudentServiceImpl();
		return studentService;
	}

}
