package com.yash.factory;

import com.yash.dao.DepartmentDAO;
import com.yash.dao.JDBCDepartmentDAOImpl;
import com.yash.service.DepartmentService;
import com.yash.service.DepartmentServiceImpl;

public class FactoryDepartment {

	public static DepartmentDAO createDepartmentDAO() {
		DepartmentDAO departmentDAO=new JDBCDepartmentDAOImpl();
		return departmentDAO;
	}
	
	public static DepartmentService createDepartmentService() {
		DepartmentService departmentService=new DepartmentServiceImpl();
		return departmentService;
	}
}
