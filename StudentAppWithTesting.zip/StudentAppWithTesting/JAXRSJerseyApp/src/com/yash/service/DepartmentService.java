package com.yash.service;

import com.yash.model.DepartmentResponse;

public interface DepartmentService {
	
	public DepartmentResponse getDepartmentServiceById(int departmentId);

}
