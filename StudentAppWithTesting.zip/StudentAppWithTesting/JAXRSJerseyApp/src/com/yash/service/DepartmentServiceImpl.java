package com.yash.service;

import java.sql.SQLException;

import com.yash.dao.DepartmentDAO;
import com.yash.entity.Department;
import com.yash.factory.FactoryDepartment;
import com.yash.model.DepartmentResponse;

public class DepartmentServiceImpl implements DepartmentService {

	private DepartmentDAO departmentDAO=null;
	
	public DepartmentServiceImpl() {
		this.departmentDAO=FactoryDepartment.createDepartmentDAO();
		
	}
	@Override
	public DepartmentResponse getDepartmentServiceById(int departmentId) {
		// TODO Auto-generated method stub
		DepartmentResponse departmentResponse=new DepartmentResponse();
		try {
			Department department=departmentDAO.getDepartmentById(departmentId);
			departmentResponse.setDepartmentId(department.getDepartmentId());
			departmentResponse.setDepartmentName(department.getDepartmentName());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return departmentResponse;
	}

}
