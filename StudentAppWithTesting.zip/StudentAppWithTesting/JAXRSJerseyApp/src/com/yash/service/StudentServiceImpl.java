package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public class StudentServiceImpl implements StudentService{
	
	private StudentDAO studentDAO=null;
	public StudentServiceImpl() {
		this.studentDAO=FactoryStudent.createStudentDAO();
	}
	@Override
	public List<Student> studentRetirevalService() {
		// TODO Auto-generated method stub
		List<Student> studentList=new ArrayList<>();
		try {
			studentList=studentDAO.getAllStudents();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentList;
	}
	@Override
	public StudentResponse studentByRollNo(int rollNo) {
		// TODO Auto-generated method stub
		StudentResponse studentResponse=new StudentResponse();

		try {
			Student student=studentDAO.getStudentByRollNo(rollNo);
			studentResponse.setRollNo(student.getRollNo());
			studentResponse.setStudentName(student.getStudentName());
			studentResponse.setStudentAddress(student.getStudentAddress());

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return studentResponse;
	}
	@Override
	public boolean registerStudent(StudentRequest studentRequest) {
		// TODO Auto-generated method stub
		
		Student student=new Student();
		student.setRollNo(studentRequest.getRollNo());
		student.setStudentName(studentRequest.getStudentName());
		student.setStudentAddress(studentRequest.getStudentAddress());
		boolean result=false;
		
		try {
			result=studentDAO.persistStudent(student);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public StudentResponses studentRetrievalService_xml() {
		// TODO Auto-generated method stub
		StudentResponses studentResponses=new StudentResponses();
		try {
			List<Student> studentList=studentDAO.getAllStudents();
			List<StudentResponse> studentResponsesList=new ArrayList<>();
			for(Student student:studentList) {
				StudentResponse studentResponse=new StudentResponse();
				studentResponse.setRollNo(student.getRollNo());
				studentResponse.setStudentName(student.getStudentName());
				studentResponse.setStudentAddress(student.getStudentAddress());
				studentResponsesList.add(studentResponse);
			}
			studentResponses.setStudentResponse(studentResponsesList);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponses;
	}
	@Override
	public boolean updateStudentAddress(int rollNo, String studentAddress) {
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			result=studentDAO.updateStudentAddress(rollNo, studentAddress);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean deleteStudent(int rollNo) {
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			result=studentDAO.deleteStudent(rollNo);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public StudentResponses studentRetrievalService(String status,int departmentId) {
		// TODO Auto-generated method stub
		StudentResponses studentResponses=new StudentResponses();
		try {
			List<Student> studentList=studentDAO.getAllStudents(status,departmentId);
			List<StudentResponse> studentResponsesList=new ArrayList<>();
			for(Student student:studentList) {
				StudentResponse studentResponse=new StudentResponse();
				studentResponse.setRollNo(student.getRollNo());
				studentResponse.setStudentName(student.getStudentName());
				studentResponse.setStudentAddress(student.getStudentAddress());
				studentResponsesList.add(studentResponse);
			}
			studentResponses.setStudentResponse(studentResponsesList);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponses;	
		}

}
