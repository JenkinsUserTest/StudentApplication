package com.yash.service;

import java.util.List;

import com.yash.entity.Student;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public interface StudentService {
	
	public StudentResponses studentRetrievalService_xml();
	public StudentResponses studentRetrievalService(String status,int departmentId);
	public List<Student> studentRetirevalService();
	public StudentResponse studentByRollNo(int rollNo);
	public boolean registerStudent(StudentRequest studentRequest);
	public boolean updateStudentAddress(int rollNo,String studentAddress);
	public boolean deleteStudent(int rollNo);

}
