package com.yash.integrate;

import java.util.ResourceBundle;

public class DataSource {
	
	private String url;
	private String driver;
	private String username;
	private String password;
	
	public DataSource(String baseName) {
		ResourceBundle resourceBundle=ResourceBundle.getBundle(baseName);
		this.driver=resourceBundle.getString("driver");
		this.url=resourceBundle.getString("url");
		this.username=resourceBundle.getString("username");
		this.password=resourceBundle.getString("password");
	}

	public String getUrl() {
		return url;
	}

	public String getDriver() {
		return driver;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	
	

}
