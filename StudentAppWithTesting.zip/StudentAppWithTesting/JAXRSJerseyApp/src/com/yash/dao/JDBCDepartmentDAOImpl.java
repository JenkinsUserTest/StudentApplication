package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Department;
import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;

public class JDBCDepartmentDAOImpl implements DepartmentDAO {

	@Override
	public Department getDepartmentById(int departmentId) throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select * from department where department_id=?");
		statement.setInt(1, departmentId);
		ResultSet resultSet=statement.executeQuery();
		Department department=new Department();

		while(resultSet.next()) {
			department.setDepartmentId(resultSet.getInt("department_id"));
			department.setDepartmentName(resultSet.getString("department_name"));
		}
		ConnectionManager.closeConnection();
		return department;	}

}
