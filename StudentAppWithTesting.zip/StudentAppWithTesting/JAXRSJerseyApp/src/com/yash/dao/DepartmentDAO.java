package com.yash.dao;

import java.sql.SQLException;

import com.yash.entity.Department;

public interface DepartmentDAO {
	
	public Department getDepartmentById(int departmentId) throws ClassNotFoundException,SQLException;

}
