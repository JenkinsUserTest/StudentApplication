package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;

public class JDBCStudentDAOImpl implements StudentDAO {
	@Override
	public List<Student> getAllStudents() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery("select * from student");
		List<Student> studentList=new ArrayList<>();
		while(resultSet.next()) {
			Student student=new Student();
			student.setRollNo(resultSet.getInt("roll_no"));
			student.setStudentName(resultSet.getString("student_name"));
			student.setStudentAddress(resultSet.getString("student_address"));
			studentList.add(student);
		}
		ConnectionManager.closeConnection();
		return studentList;
	}

	@Override
	public Student getStudentByRollNo(int rollNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("select * from student where roll_no=?");
		statement.setInt(1, rollNo);
		ResultSet resultSet=statement.executeQuery();
		Student student=new Student();
		while(resultSet.next()) {
			student.setRollNo(resultSet.getInt("roll_no"));
			student.setStudentName(resultSet.getString("student_name"));
			student.setStudentAddress(resultSet.getString("student_address"));
		}
		return student;
	}

	@Override
	public boolean persistStudent(Student student) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("insert into student values(?,?,?)");
		statement.setInt(1, student.getRollNo());
		statement.setString(2, student.getStudentName());
		statement.setString(3, student.getStudentAddress());
		int rows=statement.executeUpdate();
		if(rows>0)
			return true;
		else
		return false;
	}

	@Override
	public boolean updateStudentAddress(int rollNo, String address) throws ClassNotFoundException, 
	SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("Update student set "
				+ "student_address=? where roll_no=?");
		statement.setString(1, address);
		statement.setInt(2, rollNo);
		int rows=statement.executeUpdate();
		ConnectionManager.closeConnection();
		if(rows>0)
			return true;
		else
		return false;
		
	}

	@Override
	public boolean deleteStudent(int rollNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("delete from student where roll_no=?");
		statement.setInt(1, rollNo);
		int rows=statement.executeUpdate();
		ConnectionManager.closeConnection();
		if(rows>0)
			return true;
		else
		return false;
	}

	@Override
	public List<Student> getAllStudents(String status,int departmentId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select * from student where student_status=? and department_id=?");
		statement.setString(1, status);
		statement.setInt(2, departmentId);
		ResultSet resultSet=statement.executeQuery();
		List<Student> studentList=new ArrayList<>();
		while(resultSet.next()) {
			Student student=new Student();
			student.setRollNo(resultSet.getInt("roll_no"));
			student.setStudentName(resultSet.getString("student_name"));
			student.setStudentAddress(resultSet.getString("student_address"));
			studentList.add(student);
		}
		ConnectionManager.closeConnection();
		return studentList;
	}
}
