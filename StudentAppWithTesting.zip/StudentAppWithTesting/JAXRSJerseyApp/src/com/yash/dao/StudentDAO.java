package com.yash.dao;

import java.sql.SQLException;
import java.util.List;

import com.yash.entity.Student;

public interface StudentDAO {
	
	public List<Student> getAllStudents(String status,int departmentId)throws ClassNotFoundException, SQLException;
	public List<Student> getAllStudents()throws ClassNotFoundException, SQLException;
	public Student getStudentByRollNo(int rollNo) throws ClassNotFoundException,SQLException;
	public boolean persistStudent(Student student) throws ClassNotFoundException,SQLException;
	public boolean updateStudentAddress(int rollNo,String address) throws ClassNotFoundException,SQLException;
	public boolean deleteStudent(int rollNo)throws ClassNotFoundException,SQLException;

}
