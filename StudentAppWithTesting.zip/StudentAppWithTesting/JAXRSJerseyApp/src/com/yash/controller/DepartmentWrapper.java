package com.yash.controller;

import java.io.StringReader;
import java.util.List;


import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


import com.yash.model.DepartmentResponse;
import com.yash.model.StudentResponse;

public class DepartmentWrapper {
	/*
	public DepartmentResponse getDepartmentResponse(int departmentId) throws JAXBException {
		Client client = ClientBuilder.newClient( new ClientConfig().register( LoggingFilter.class ) );
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSJerseyApp/rest/student-app").
				path("/students-xml");
	
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_XML);
		javax.ws.rs.core.Response response = invocationBuilder.get();

		JAXBContext jaxbContext     = JAXBContext.newInstance( DepartmentResponse.class );
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		
		DepartmentResponse departmentResponse = (DepartmentResponse) jaxbUnmarshaller.
				unmarshal(new StringReader(response.getEntity().toString()));
		return departmentResponse;
	}*/

}
