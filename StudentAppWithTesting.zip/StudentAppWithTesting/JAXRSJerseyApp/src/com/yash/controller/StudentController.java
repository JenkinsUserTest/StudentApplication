package com.yash.controller;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;
import com.yash.model.DepartmentResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;
import com.yash.service.StudentService;

@Path("/student-app")
public class StudentController {
	
	private StudentService studentService=null;
	public StudentController() {
		this.studentService=FactoryStudent.createStudentService();
	}
	
	@GET
	@Path("/students-xml")
	@Produces(MediaType.APPLICATION_XML)
	public StudentResponses getAllStudents_xml(){
		StudentResponses studentResponses=studentService.studentRetrievalService_xml();
		return studentResponses;
	}

	@GET
	@Path("/students")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Student> getAllStudents(@MatrixParam("departmentId")int departmentId){
		List<Student> studentList=studentService.studentRetirevalService();
		return studentList;
	}
	@GET
	@Path("/allstudents")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Student> getAllStudentsT(){
		System.out.println("--get all students---");
		List<Student> studentList=studentService.studentRetirevalService();
		return studentList;
	}
	
	@GET
	@Path(value="/students-test/{status}/{year}")
	@Produces(MediaType.APPLICATION_JSON)
	public StudentResponses getAllStudentsBasedOnDepartmentId(@PathParam("status") String status,
			@MatrixParam("departmentId")int departmentId,
			@PathParam("year") String year,
			@MatrixParam("departmentId")int departmentId1
			){
		StudentResponses studentResponses=studentService.studentRetrievalService(status,departmentId);
		
		
		//DepartmentWrapper wrapper=new DepartmentWrapper();
		//DepartmentResponse departmentResponse=new DepartmentResponse();
		/*
		try {
			departmentResponse=wrapper.getDepartmentResponse(departmentId);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		studentResponses.setDepartmentResponse(departmentResponse);
		*/
		return studentResponses;
	}
	
	

	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="/students/{rollNo}")
	@GET
	public Response retrieveStudentRollNo(@PathParam("rollNo") int rollNo) {
		StudentResponse response=studentService.studentByRollNo(rollNo);
		System.out.println("Retrieve student by roll No");
		return Response
			      .status(Response.Status.OK)
			      .type(MediaType.APPLICATION_JSON)
			      .entity(response)
			      .build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Path(value="/students-xml")
	public Response registerStudent_xml(StudentRequest studentRequest) {	
	boolean result=studentService.registerStudent(studentRequest);
	if(result)
	{
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(studentRequest.getRollNo());
		studentResponse.setStudentName(studentRequest.getStudentName());
		studentResponse.setStudentAddress(studentRequest.getStudentAddress());
		return Response
			      .status(Response.Status.OK)
			      .type(MediaType.APPLICATION_XML)
			      .entity(studentResponse)
			      .build();
	}else {
		return Response
			      .status(Response.Status.CONFLICT)
			      .type(MediaType.APPLICATION_XML)
			      .build();
	}	
	}
		
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path(value="/students")
	public Response registerStudent(@FormParam("rollNo")
	int rollNo,@FormParam("studentName") String studentName,
	@FormParam("studentAddress") String studentAddress) {
		
	    StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(rollNo);
		studentRequest.setStudentName(studentName);
		studentRequest.setStudentAddress(studentAddress);
		boolean result=studentService.registerStudent(studentRequest);
		if(result)
		{
			return Response
				      .status(Response.Status.OK)
				      .type(MediaType.APPLICATION_JSON)
				      .entity(studentRequest)
				      .build();
		}else {
			return Response
				      .status(Response.Status.CONFLICT)
				      .type(MediaType.APPLICATION_JSON)
				      .build();
		}
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_XML)
	@Path(value="/students")
	public Response updateAddress(@QueryParam("rollNo") int rollNo,
			@QueryParam("studentAddress")String studentAddress) {
		boolean result=studentService.updateStudentAddress(rollNo, studentAddress);
		StudentResponse response=studentService.studentByRollNo(rollNo);
		if(result) {
		return Response
			      .status(Response.Status.OK)
			      .type(MediaType.APPLICATION_XML)
			      .entity(response)
			      .build();
		}else {
			return Response
				      .status(Response.Status.NOT_FOUND)
				      .type(MediaType.APPLICATION_XML)
				      .build();
		}
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_XML)
	@Path(value="/students")
	public Response deleteStudent(@MatrixParam("rollNo") int rollNo) {
		boolean result=studentService.deleteStudent(rollNo);
		if(result) {
			return Response
				      .status(Response.Status.OK)
				      .type(MediaType.APPLICATION_XML)
				      .build();
			}else {
				return Response
					      .status(Response.Status.NOT_FOUND)
					      .type(MediaType.APPLICATION_XML)
					      .build();
			}	}
	
}

