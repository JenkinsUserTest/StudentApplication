package com.yash.controller;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.yash.factory.FactoryDepartment;
import com.yash.model.DepartmentResponse;
import com.yash.service.DepartmentService;

@Path("department-app")
public class DepartmentController {
	private DepartmentService departmentService=null;
	public DepartmentController() {
		this.departmentService=FactoryDepartment.createDepartmentService();
	}
	
	@GET
	@Path("/departments")
	@Produces(MediaType.APPLICATION_JSON)
	public Response retrieveDepartmentById(@MatrixParam("departmentId") int departmentId) {
		DepartmentResponse departmentResponse=departmentService.getDepartmentServiceById(departmentId);
		return Response
	      .status(Response.Status.OK)
	      .type(MediaType.APPLICATION_JSON)
	      .entity(departmentResponse)
	      .build();
		
		
	}

}
