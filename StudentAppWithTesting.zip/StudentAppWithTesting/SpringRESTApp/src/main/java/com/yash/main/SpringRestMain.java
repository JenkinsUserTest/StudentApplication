package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

import com.yash.configuration.ValidationConfiguration;
import com.yash.security.SpringSecurityConfig;

@SpringBootApplication
@ComponentScan(basePackages = "com.yash.*")
@ImportResource("classpath:applicationContext.xml")
@Import({ValidationConfiguration.class,SpringSecurityConfig.class})
public class SpringRestMain {
	public static void main(String args[]) {
		SpringApplication.run(SpringRestMain.class, args);
	}

}
