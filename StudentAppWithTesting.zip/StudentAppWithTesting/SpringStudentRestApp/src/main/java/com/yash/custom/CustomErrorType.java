package com.yash.custom;
public class CustomErrorType {
	private int statusCode;
	private String message;

	public CustomErrorType(int statusCode,String message) {		
		this.statusCode=statusCode;
		this.message=message;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getMessage() {
		return message;
	}
	
	
}
