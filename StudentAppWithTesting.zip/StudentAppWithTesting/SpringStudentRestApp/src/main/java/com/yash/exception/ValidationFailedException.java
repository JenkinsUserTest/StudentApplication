package com.yash.exception;

public class ValidationFailedException extends Throwable {
	
	private String message;
	
	public ValidationFailedException(String message) {
		super(message);
	}
	
	public String getMessage() {
		return message;
	}

}
