package com.yash.test;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockServletContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.controller.StudentController;
import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;
import com.yash.integrate.DataSource;
import com.yash.main.SpringRestMain;
import com.yash.model.StudentResponse;
import com.yash.security.AuthenticationEntryPoint;
import com.yash.security.SpringSecurityConfig;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MockServletContext.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = {SpringRestMain.class}
     )   		

public class TestStudentRestAppSecurity {

	private MockMvc mockMvc;
	@Autowired
	private FilterChainProxy springSecurityFilterChain;
	
	@Spy
	@Autowired
	private StudentServiceImpl studentServiceImpl;
	@Spy
	@Autowired
	private JDBCStudentDAOImpl jdbcStudentDAOImpl;
	@Spy
	@Autowired
	private ConnectionManager connectionManager;
	@Spy
	@Autowired
	private DataSource dataSource;
	
	 @InjectMocks
	 private StudentController studentController;
	 
	 @Autowired
	 private TestRestTemplate template;
	 
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .apply(SecurityMockMvcConfigurers.springSecurity(springSecurityFilterChain))
	                .build();
	    }
    
	
		@WithMockUser(username = "jjjjj",password = "user123",roles = {"userrole"})
		@Test
		//@WithUserDetails("yashuser")
		public void test_auth_positive() throws Exception {			
			        mockMvc.perform(MockMvcRequestBuilders.get("/api/students")
		            .accept(MediaType.ALL))
		            .andExpect(status().isOk());
		}
		
		@Test
		public void integerationTestAuthActualUser() {
			ResponseEntity<Student> result=
					template.withBasicAuth("yashuser", "user123").getForEntity("/api/students/1", Student.class);
		assertEquals(HttpStatus.OK,result.getStatusCode());
		}
		
		@Test
		public void integerationTestRestTemplateWithAuthentication() {
			RestTemplate template=new RestTemplate();		     
			String auth="yashuser"+":"+"user123";			
			HttpHeaders headers=new HttpHeaders();
			  byte[] encodedAuth = Base64.encode( 
			          auth.getBytes(Charset.forName("US-ASCII")) );
			       String authHeader = "Basic " + new String( encodedAuth );
			   headers.add("Authorization", authHeader);
			String url="http://localhost:8083/studentapp/api/students/{rollNo}";
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> requestEntity=new HttpEntity<String>(headers);
			ResponseEntity<StudentResponse> response=
					template.exchange(url, HttpMethod.GET, requestEntity, StudentResponse.class,1);
			StudentResponse studentResponse=response.getBody();
			assertEquals(1,studentResponse.getRollNo());
		}
		
		@Test
		public void integrationTestJSONResponseWithHttpClient() throws ClientProtocolException, IOException {
		    HttpUriRequest request = new HttpGet("http://localhost:8083/studentapp/api/students/1" );
	         String auth="yashuser"+":"+"user123";
			  byte[] encodedAuth = Base64.encode( 
			          auth.getBytes(Charset.forName("US-ASCII")) );
			       String authHeader = "Basic " + new String( encodedAuth );
			       request.addHeader("Authorization", authHeader);
		    HttpResponse response = HttpClientBuilder.create().build().execute(request);
		    String jsonFromResponse = EntityUtils.toString(response.getEntity());
		    ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		   StudentResponse studentResponse= mapper.readValue(jsonFromResponse, StudentResponse.class);
		   assertEquals(1,studentResponse.getRollNo());
		}

}
