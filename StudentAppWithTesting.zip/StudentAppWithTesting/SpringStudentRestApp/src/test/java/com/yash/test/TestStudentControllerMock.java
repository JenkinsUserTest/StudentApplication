package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Entity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.controller.StudentController;
import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentControllerMock {
	 private MockMvc mockMvc;

	 @Mock
	 private StudentService studentService;
	
	 @InjectMocks
	 private StudentController studentController;
	 
	    @Mock
		private RestTemplate restTemplate;
	    
	    private MockRestServiceServer mockServer;
	    
	    private RestTemplate template;
		
		private ObjectMapper mapper=new ObjectMapper();
	 
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .build();
	        template=new RestTemplate();
			mockServer=MockRestServiceServer.createServer(template);
	    }
	   
	@Test
	public void test_retieveAllStudents_positive() {
		try {
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1001);
		studentResponse.setStudentName("sabbir");
		studentResponse.setStudentAddress("abc");
		studentResponseList.add(studentResponse);
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		assertEquals(true,studentList.size()>0);
		}catch(NullPointerException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_retieveAllStudents_positive_data_test() {
		try {
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1001);
		studentResponse.setStudentName("sabbir");
		studentResponse.setStudentAddress("abc");
		studentResponseList.add(studentResponse);
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		   assertEquals(1001,studentList.get(0).getRollNo());
		}catch(IndexOutOfBoundsException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_retieveAllStudents_negative(){
		
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1);
		studentResponse.setStudentName("test");
		studentResponse.setStudentAddress("test");
	   try {
		   when(studentList.get(0).getRollNo()==(studentResponse.getRollNo()));
		   assertTrue(false);
	   }catch(IndexOutOfBoundsException e) {
		   assertTrue(true);   
	   }
	}
	@Test
	public void test_persistStudent_positive() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(22);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    
		Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");   
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(true);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void test_persistStudent_negative() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
	    Errors mock=Mockito.mock(Errors.class);
	    when(mock.hasErrors()).thenReturn(true);
	    
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Not Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_persistStudent_positive_validation() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	   
		Errors mock=Mockito.mock(Errors.class);
	    when(mock.hasErrors()).thenReturn(true);
	    List<ObjectError> objectErrorList=new ArrayList<ObjectError>();
	    ObjectError objectError=new ObjectError("validation error", "student name cannot be blank");
	    objectErrorList.add(objectError);
	    when(mock.getAllErrors()).thenReturn(objectErrorList);
	    
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, mock);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("valiation error",studentRegisteredResponse.getResponseMessage());
		List<StudentError> studentErrorList=studentRegisteredResponse.getStudentError();
		assertEquals(true,studentErrorList.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_persistStudent_exception() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
		when(studentService.studentRegistrationService(studentRequest)).thenThrow(StudentDAOException.class);
		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
        assertTrue(false);
		}catch(Exception e) {
			assertTrue(true);
		}
	}
	@Test
	public void retrieveStudentByRollNo(){
		when(studentService.studentRetrievalServiceByRollNo(Mockito.anyInt())).thenAnswer(new Answer<StudentResponse>(){

			public StudentResponse answer(InvocationOnMock invocation) throws Throwable {
			StudentResponse response=new StudentResponse();
			response.setRollNo(1001);
			response.setStudentName("xyz");
			response.setStudentAddress("abc");
			return response;
			}
			
		});
		
		studentController.retrieveStudentByRollNo(1001);
		
	}
	
	@Test
	public void testGetStudentURIPositive() {
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1);
		when(studentService.studentRetrievalServiceByRollNo(anyInt())).thenReturn(studentResponse);
		try {
			MvcResult result=mockMvc.perform(get("/api/students/{rollNo}",1))
			.andExpect(status().isOk()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	@Test
	public void testGetStudentURINegative() {
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(0);
		when(studentService.studentRetrievalServiceByRollNo(anyInt())).thenReturn(studentResponse);
		try {
			MvcResult result=mockMvc.perform(get("/api/students/{rollNo}",99))
			.andExpect(status().isNotFound()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testUpdateStudentAddressURI_positive() {
		when(studentService.updateStudentAddressService(anyInt(), anyString())).thenReturn(true);
		try {
			MvcResult mvcResult=mockMvc.perform(patch("/api/students/{rollNo}/{studentAddress}",1,"new Address"))
					.andExpect(status().isAccepted()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testRestTemplatePositive() {
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1);
		studentResponse.setStudentName("Sabbir");
		studentResponse.setStudentAddress("xyz");
	    when(restTemplate.getForEntity("/api/students/1001", StudentResponse.class))
	    .thenReturn(new ResponseEntity<StudentResponse>(studentResponse,HttpStatus.OK));
	    ResponseEntity<StudentResponse> responseEntity=restTemplate.getForEntity("/api/students/1", StudentResponse.class);
	    StudentResponse response=responseEntity.getBody();
	    assertEquals(1,response.getRollNo());    
	}
	
	@Test
	public void testMockServer_Positive(){
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1);
		studentResponse.setStudentName("Sabbir");
		studentResponse.setStudentAddress("xyz");
		try {
			mockServer.expect(ExpectedCount.once(),
					requestTo(new URI("/api/students/1")))
					.andExpect(method(HttpMethod.GET))
					.andRespond(withStatus(HttpStatus.OK)
					.contentType(MediaType.APPLICATION_JSON)
					.body(mapper.writeValueAsString(studentResponse))
					);
			ResponseEntity<StudentResponse>
			responseEntity=template.getForEntity("/api/students/1",StudentResponse.class);
			StudentResponse response=responseEntity.getBody();
		    assertEquals(1,response.getRollNo());
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testActualJSONResponse() throws ClientProtocolException, IOException {
	    HttpUriRequest request = new HttpGet("http://localhost:8083/studentapp/api/students/1" );
         String auth="yashuser"+":"+"user123";
		  byte[] encodedAuth = Base64.encode( 
		          auth.getBytes(Charset.forName("US-ASCII")) );
		       String authHeader = "Basic " + new String( encodedAuth );
		       request.addHeader("Authorization", authHeader);
	    HttpResponse response = HttpClientBuilder.create().build().execute(request);
	    String jsonFromResponse = EntityUtils.toString(response.getEntity());
	    ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	   StudentResponse studentResponse= mapper.readValue(jsonFromResponse, StudentResponse.class);
	   assertEquals(1,studentResponse.getRollNo());
	}

}
