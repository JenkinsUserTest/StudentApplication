package com.yash.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class StudentResponses {
	
	private List<StudentResponse> studentResponse;

	public List<StudentResponse> getStudentResponse() {
		return studentResponse;
	}

	public void setStudentResponse(List<StudentResponse> studentResponse) {
		this.studentResponse = studentResponse;
	}
	
	

}
