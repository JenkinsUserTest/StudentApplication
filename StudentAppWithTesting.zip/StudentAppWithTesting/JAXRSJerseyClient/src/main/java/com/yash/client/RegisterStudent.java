package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

public class RegisterStudent {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client client = ClientBuilder.newClient( new ClientConfig().register( LoggingFilter.class ) );
				WebTarget webTarget = client.
				target("http://localhost:8081/JAXRSJerseyApp/rest/student-app/students");		
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(1003);
        studentRequest.setStudentAddress("aabb");
        studentRequest.setStudentName("mahesh");
		
		Response response = invocationBuilder.post(Entity.entity(studentRequest,
				MediaType.APPLICATION_JSON));
		System.out.println(response.readEntity(StudentResponse.class));

	}
}
