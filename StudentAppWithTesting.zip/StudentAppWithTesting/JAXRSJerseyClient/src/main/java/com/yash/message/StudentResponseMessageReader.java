package com.yash.message;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public class StudentResponseMessageReader implements MessageBodyReader<StudentResponse>{

	public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		// TODO Auto-generated method stub
	    return type == StudentResponse.class;
	}

	public StudentResponse readFrom(Class<StudentResponse> type, Type genericType, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException, WebApplicationException {
		// TODO Auto-generated method stub
		 try {
		        JAXBContext jaxbContext = JAXBContext.newInstance(StudentResponse.class);
		        StudentResponse studentResponse = (StudentResponse) jaxbContext.createUnmarshaller()
		            .unmarshal(entityStream);
		        return studentResponse;
		    } catch (JAXBException jaxbException) {
		        throw new ProcessingException("Error deserializing a StudentResponse.",
		            jaxbException);
		    }
	}

}
