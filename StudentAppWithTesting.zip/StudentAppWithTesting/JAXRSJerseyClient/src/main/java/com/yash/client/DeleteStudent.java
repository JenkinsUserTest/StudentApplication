package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

import com.yash.message.StudentRequestMessageBodyWriter;
import com.yash.message.StudentResponseMessageReader;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

public class DeleteStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Client client = ClientBuilder.newClient( 
				new ClientConfig().register( StudentRequestMessageBodyWriter.class ) 
				.register(StudentResponseMessageReader.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSJerseyApp/rest/student-app")
				.path("students").matrixParam("rollNo", 1025);
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder
                .delete();
		System.out.println("Response status:"+response.getStatus());
	 
	}

}
