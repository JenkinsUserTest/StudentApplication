package com.yash.client;

import java.io.StringReader;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public class RetrieveStudents {

	public static void main(String[] args) throws JAXBException {
		// TODO Auto-generated method stub

		Client client = ClientBuilder.newClient( new ClientConfig().register( LoggingFilter.class ) );
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSJerseyApp/rest/student-app").
				path("/students-xml");
	
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.get();
		String students = response.readEntity(String.class);
		
		JAXBContext jaxbContext     = JAXBContext.newInstance( StudentResponses.class );
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		
		StudentResponses studentResponses = (StudentResponses) jaxbUnmarshaller.
				unmarshal(new StringReader(students));
		List<StudentResponse> studentResponseList=studentResponses.getStudentResponse();
		for(StudentResponse studentResponse:studentResponseList) {
			System.out.println(studentResponse);
		}
		
	}

}
