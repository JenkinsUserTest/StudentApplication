package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Result;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.message.StudentResponseMessageReader;
import com.yash.message.StudentRequestMessageBodyWriter;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public class RegisterStudent_XML {

	public static void main(String[] args) throws JAXBException {
		// TODO Auto-generated method stub
		Client client = ClientBuilder.newClient( 
				new ClientConfig().register( StudentRequestMessageBodyWriter.class ) 
				.register(StudentResponseMessageReader.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSJerseyApp/rest/student-app/students-xml");		
        Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_XML);
        StudentRequest studentRequest=new StudentRequest();
        studentRequest.setRollNo(1029);
        studentRequest.setStudentAddress("abc");
        studentRequest.setStudentName("rohit");

Response response = invocationBuilder.post(Entity.xml(studentRequest));
System.out.println(response.readEntity(StudentResponse.class));

	}

}
