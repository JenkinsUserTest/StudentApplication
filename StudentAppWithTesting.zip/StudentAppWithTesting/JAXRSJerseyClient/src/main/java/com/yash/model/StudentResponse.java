package com.yash.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class StudentResponse {

	private int rollNo;
	private String studentName;
	private String studentAddress;
	
	public StudentResponse() {}
	
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentAddress() {
		return studentAddress;
	}
	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}


	@Override
	public String toString() {
		return "StudentResponse [rollNo=" + rollNo + ", studentName=" + studentName + ", studentAddress="
				+ studentAddress + "]";
	}
	
	
}
