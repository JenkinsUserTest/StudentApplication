package com.yash.proxy;

public class MyClassCopy {
private int i;	
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public void then(String str) {
		System.out.println(str);
	}
	public String x(String str) {
		return str;
	}

}
