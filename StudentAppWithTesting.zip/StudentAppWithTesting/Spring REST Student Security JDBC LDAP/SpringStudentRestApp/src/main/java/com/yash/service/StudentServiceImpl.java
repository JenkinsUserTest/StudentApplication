package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDAO studentDAO;

	public List<StudentResponse> studentRetrievalService() {
		// TODO Auto-generated method stub
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		try {
			List<Student> studentList=studentDAO.getAllStudents();
			for(Student student:studentList) {
				StudentResponse studentResponse=new StudentResponse();
				studentResponse.setRollNo(student.getRollNo());
				studentResponse.setStudentName(student.getStudentName());
				studentResponse.setStudentAddress(student.getStudentAddress());
				studentResponseList.add(studentResponse);
			}
		} catch(StudentDAOException e) {
			e.printStackTrace();
		}
		System.out.println(studentResponseList);
		return studentResponseList;
	}

	public StudentResponse studentRetrievalServiceByRollNo(int rollNo) {
		// TODO Auto-generated method stub
		StudentResponse studentResponse=new StudentResponse();
		try {
			Student student=studentDAO.getStudentByRollNo(rollNo);
			studentResponse.setRollNo(student.getRollNo());
			studentResponse.setStudentName(student.getStudentName());
			studentResponse.setStudentAddress(student.getStudentAddress());
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponse;
	}

	public boolean studentRegistrationService(StudentRequest studentRequest) {
		// TODO Auto-generated method stub
		Student student=new Student();
		student.setRollNo(studentRequest.getRollNo());
		student.setStudentName(studentRequest.getStudentName());
		student.setStudentAddress(studentRequest.getStudentAddress());
		boolean result=false;
		try {
			result=studentDAO.registerStudentData(student);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	public boolean updateStudentService(StudentRequest studentRequest) {
		// TODO Auto-generated method stub
		Student student=new Student();
		student.setRollNo(studentRequest.getRollNo());
		student.setStudentName(studentRequest.getStudentName());
		student.setStudentAddress(studentRequest.getStudentAddress());
		boolean result=false;
		try {
			result=studentDAO.updateStudentData(student);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;	
		}
	
	public boolean updateStudentAddressService(int rollNo, String newAddress) {
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			result=studentDAO.updateStudentAddress(rollNo, newAddress);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		}

	public boolean deleteStudentService(int rollNo){
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			result=studentDAO.deleteStudent(rollNo);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		}

}
