package com.yash.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.yash.validation.RollNoConstraint;

public class StudentRequest {
	
	@RollNoConstraint(message="{rollNo.size}")
	private int rollNo;
	@NotBlank(message = "{studentName.blank}")
	private String studentName;
	@Size(min=5,max=10,message = "size must be between {min} and {max}")
	private String studentAddress;
	
	public StudentRequest() {
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}
	
	

}
