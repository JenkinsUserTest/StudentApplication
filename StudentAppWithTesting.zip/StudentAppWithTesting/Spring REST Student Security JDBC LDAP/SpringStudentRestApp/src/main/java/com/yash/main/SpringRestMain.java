package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableLoadTimeWeaving;
import org.springframework.context.annotation.EnableLoadTimeWeaving.AspectJWeaving;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

import com.yash.configuration.DBConfiguration;
import com.yash.configuration.EmbeddedLdapConfiguration;
import com.yash.configuration.SecurityConfiguration;
import com.yash.configuration.ValidationConfiguration;
import com.yash.security.JDBCSpringSecurityConfig;
import com.yash.security.LDAPSpringSecurityConfig;
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = "com.yash.*")
@ImportResource("classpath:applicationContext.xml")
//@Import({ValidationConfiguration.class,LDAPSpringSecurityConfig.class,EmbeddedLdapConfiguration.class})
public class SpringRestMain {
	public static void main(String args[]) {
		SpringApplication.run(SpringRestMain.class, args);
	}

}
