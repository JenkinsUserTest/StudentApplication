package com.yash.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.yash.model.StudentResponse;

//@Aspect
//@Component
public class DebuggingAspect {
	@Before("execution(* com.yash.*.*.*(..))")
	public void beforeAdvice(JoinPoint method) {
		System.out.println("Debugging Before advice on "+method.getSignature().getName());
	}

	@After("execution(* com.yash.*.*.*(..))")
	public void afterAdvice(JoinPoint method) {
		System.out.println("Debugging After advice on "+method.getSignature().getName());
	}
	
	@AfterReturning(pointcut ="execution(* com.yash.*.*.*(..))",
		      returning= "result")
	public void afterReturning(JoinPoint method,Object result){
		System.out.println("Debugging After returning on "+method.getSignature().getName()+" returned "+result);
	}
	
	@AfterThrowing(pointcut ="execution(* com.yash.*.*.*(..))",
		      throwing= "error")
	public void afterThrowing(JoinPoint method,Throwable error){
		System.out.println("Debugging After throwing on "+ method.getSignature().getName()+" "+" threw exception "+error);
	}
	
	@Pointcut("execution(* com.yash.controller.StudentController.retrieveAllStudents(..))")
	public void getPointCut(){		
	}
	
	@Pointcut("execution(* com.yash.controller.StudentController.x(..)) ")
	public void getPointCutX(){		
	}
    
	
	@Around(value="execution( (int) com.yash.controller.StudentController.x(..))")	
	public Object aroundAdviceX(ProceedingJoinPoint method){
	Object object=null;
	try {
		object = method.proceed();
	} catch (Throwable e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Around advice  on x returned "+object);
	return object;
	}
	
	@Around("getPointCut()")
	public Object aroundAdvice(ProceedingJoinPoint method){
		System.out.println("Debugging Around advice on :"+ method.getSignature().getName());
		ResponseEntity<List<StudentResponse>> response=null;
		try {
			 response=(ResponseEntity<List<StudentResponse>>)method.proceed();
			
			 List<StudentResponse> studentResponseList=response.getBody();
			 StudentResponse studentResponse=new StudentResponse();
			 studentResponse.setRollNo(8888);
			 studentResponse.setStudentName("response modified by debug around advice");
			 studentResponse.setStudentAddress("response modified by debug around advice");
			 studentResponseList.add(studentResponse);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Debugging Around advice return value: "+response);
		return response;
		
	}
	
}
