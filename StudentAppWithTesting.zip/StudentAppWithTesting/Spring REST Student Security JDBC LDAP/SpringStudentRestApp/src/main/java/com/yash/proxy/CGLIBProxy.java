package com.yash.proxy;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.objectweb.asm.Type;

import net.sf.cglib.beans.BeanCopier;
import net.sf.cglib.beans.BeanGenerator;
import net.sf.cglib.beans.BeanMap;
import net.sf.cglib.beans.ImmutableBean;
import net.sf.cglib.core.Signature;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.FixedValue;
import net.sf.cglib.proxy.InterfaceMaker;
import net.sf.cglib.reflect.MethodDelegate;
public class CGLIBProxy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(MyClass.class);
		enhancer.setCallback( new FixedValue () {
			public Object loadObject() throws Exception {
				// TODO Auto-generated method stub
				return "Sabbir";
			}
		});
		
		MyClass proxy = (MyClass) enhancer.create();
		 
		String result = proxy.x("java");
		System.out.println("Result:"+result);
	
		
		Enhancer enhancer1 = new Enhancer();
		enhancer1.setSuperclass(MyInterface.class);
		enhancer1.setCallback( new FixedValue () {

		public Object loadObject() throws Exception {
				// TODO Auto-generated method stub
				return "sabbir";
			}
		} );
		MyInterface myInterfaceProxy = (MyInterface) enhancer1.create();
		 
		String result1 = myInterfaceProxy.y(null);
		System.out.println("Result:"+result1);
		
		MyClass mc=new MyClass();
		mc.setI(90);
		System.out.println("I:"+mc.getI());
		
		MyClass immutableMyClass=(MyClass)ImmutableBean.create(mc);
		//immutableMyClass.setI(100);
		
		  BeanCopier copier = BeanCopier.create(MyClass.class, MyClassCopy.class, false);
		  MyClass mc1 = new MyClass();
		  mc1.setI(101);

		  
		  MyClassCopy myClassCopy = new MyClassCopy();
		  copier.copy(mc1, myClassCopy, null);
		  System.out.println("I in my class copy:"+ myClassCopy.getI()); 
		  
		  BeanGenerator beanGenerator = new BeanGenerator();
		  beanGenerator.addProperty("value", String.class);
		  Object myBean = beanGenerator.create();
		  
		  Method setter;
		try {
			setter = myBean.getClass().getMethod("setValue", String.class);
			 try {
				setter.invoke(myBean, "test");
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  Method getter = myBean.getClass().getMethod("getValue");
			 try {
				System.out.println("getter of myBean:"+getter.invoke(myBean));
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		  MyClass mc3 = new MyClass();
		  BeanMap map = BeanMap.create(mc3);
		  mc3.setI(303);
		  System.out.println("Value of i from map:"+map.get("i"));
		  
		  
		  Signature signature = new Signature("z", Type.INT_TYPE, new Type[]{Type.INT_TYPE});
		  InterfaceMaker interfaceMaker = new InterfaceMaker();
		  Signature signature1 = new Signature("k", Type.DOUBLE_TYPE, new Type[]{Type.INT_TYPE});

		  interfaceMaker.add(signature, new Type[0]);
		 // interfaceMaker.add(signature1,new Type[0]);
		  
		  Class myInterface = interfaceMaker.create();
	
		  
		  System.out.println("Method in interface:"+myInterface.getMethods().length);
		  System.out.println("Method information:"+myInterface.getMethods()[0].getName());
		  System.out.println("Return type:"+ myInterface.getMethods()[0].getReturnType());
		  
		  MyClass mc4 = new MyClass();
		  mc4.setI(202);
		  SomeInterface delegatedToSomeInterface = (SomeInterface) MethodDelegate.create(
		      mc4, "getI", SomeInterface.class);
		  System.out.println("I:"+delegatedToSomeInterface.someMethod());
		  
	}

}
