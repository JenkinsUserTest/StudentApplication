package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

import com.yash.exception.StudentDAOException;
import com.yash.integrate.ConnectionManager;
@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	private ConnectionManager manager;
	@Override
	public UserDetails getUserDetails(String userName) throws StudentDAOException {
		// TODO Auto-generated method stub
		System.out.println("***in dao:"+userName);

		Connection connection;
		UserDetails userDetails=null;
		try {
			connection = manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("select u.username,u.password,"
					+ "u.enabled,a.authority\r\n" + 
					"from users u\r\n" + 
					"join authorities a\r\n" + 
					"on(u.username=a.username) where u.username=?");
			statement.setString(1, userName);
			ResultSet resultSet=statement.executeQuery();
			List<GrantedAuthority> authorities=new ArrayList<GrantedAuthority>();
			String userNameDB=null;
			String password=null;
			while(resultSet.next()) {
				GrantedAuthority authority=new SimpleGrantedAuthority(resultSet.getString("authority"));
				authorities.add(authority);
				userNameDB=resultSet.getString("username");
				password="{noop}"+resultSet.getString("password");
			}
			userDetails=new User(userNameDB,
					password,authorities);
		} catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");
		}
		return userDetails;
	}

}
