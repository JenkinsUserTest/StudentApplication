package com.yash.configuration;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@Configuration
@PropertySource("classpath:application.properties")
public class DBConfiguration {
	  @Autowired
	  private Environment env;
	  
	  @Bean
	  public UserDetailsService usersDetailsService() {
		  JdbcDaoImpl impl=new JdbcDaoImpl();
		  impl.setDataSource(getDataSource());
		  impl.setUsersByUsernameQuery("select user_name,password,enabled from users where username=?");
		  impl.setAuthoritiesByUsernameQuery("select u.username,a.authority from users u join authorities a on(u.username=a.username)"
					+ " where u.username=?");
		  return impl;
	  }

	  @Bean("dataSourceX")
	  public DataSource getDataSource() {
	    BasicDataSource dataSource = new BasicDataSource();
	    dataSource.setDriverClassName(env.getProperty("mysql.driver"));
	    dataSource.setUrl(env.getProperty("mysql.jdbcUrl"));
	    dataSource.setUsername(env.getProperty("mysql.username"));
	    dataSource.setPassword(env.getProperty("mysql.password"));
	    return dataSource;
	  }
	  
	  

}
