package com.yash.validation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.StudentRequest;
//@Component
public class StudentRequestValidator implements Validator {
	@Autowired
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return StudentRequest.class.equals(clazz);
	}

	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		StudentRequest studentRequest=(StudentRequest)target;
		String rollNo=String.valueOf(studentRequest.getRollNo());
		
		if(rollNo.length()<3) {
			errors.rejectValue("rollNo", "no error code","Roll no must greater than 3");
		}
		if(studentRequest.getStudentName().length()<=0) {
			errors.rejectValue("studentName", "no error code","Student name cannot be blank");
		}
		if(studentRequest.getStudentAddress().length()<=0) {
			errors.rejectValue("studentAddress", "no error code","Student address cannot be blank");
		}
		
		
		
	}


}
