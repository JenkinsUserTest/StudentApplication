package com.yash.test;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.yash.controller.StudentController;
import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentControllerSpy {
	private MockMvc mockMvc;
	
	 @Autowired
	 @Spy
	 private StudentServiceImpl studentService;
	  
	
	 @InjectMocks
	 private StudentController studentController;
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .build();
	    }
	
	@Test
	public void test_retieveAllStudents_positive() {
		try {
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		assertEquals(true,studentList.size()>0);
		}catch(IndexOutOfBoundsException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_retieveAllStudents_positive_data_test() {
		try {
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		   assertEquals(1,studentList.get(0).getRollNo());
		}catch(IndexOutOfBoundsException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_persistStudent_positive() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2223);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void test_persistStudent_negative() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
	    
		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Not Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
	}

	@Test
	public void test_persistStudent_exception() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
        assertTrue(false);
		}catch(Exception e) {
			assertTrue(true);
		}
	}
}
