package com.yash.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;

public class TestStudentServiceImpl {
	
	protected static final Class<Object> JdbcStudentDAOimpl = null;
	@InjectMocks
	private StudentServiceImpl studentServiceImpl;
	@Mock
	private StudentDAO studentDAO;
	@Before
	public void init() {
	    MockitoAnnotations.initMocks(this);
	}
	@Test
	public void testUpdateStudentService() {
	try {
		when(studentDAO.updateStudentData(Mockito.mock(Student.class))).thenAnswer(new Answer<Boolean>() {
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				// TODO Auto-generated method stub
				Student student=invocation.getArgumentAt(0, Student.class);/*
				JDBCStudentDAOImpl jdbcStudentDAOImpl=(JDBCStudentDAOImpl)Mockito.spy(JDBCStudentDAOImpl.class);
						Student student1=
								jdbcStudentDAOImpl.getStudentByRollNo(student.getRollNo());
						if(student.getRollNo()==student1.getRollNo())
							return true;
						else
							return false;
					*/	
				if(student.getRollNo()==1) {
					return true;
				}else {
				return false;
				}
			}
		});
		StudentRequest request=new StudentRequest();
		request.setRollNo(1);
		request.setStudentName("xyz");
		request.setStudentAddress("abc");
		boolean actual=studentServiceImpl.updateStudentService(request);
		assertEquals(true,actual);	
	} catch (StudentDAOException e) {
		// TODO Auto-generated catch block
		Assert.assertTrue(false);
	}
	}

}
