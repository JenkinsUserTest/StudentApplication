package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;
import com.yash.integrate.DataSource;
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestJDBCStudentDAOImpl {
	 private MockMvc mockMvc;
	 @Mock
	 private Connection connection;
	 @Mock
	 private ConnectionManager manager;
	 @Mock
	 private PreparedStatement statement;
	 @Mock
	 private DataSource dataSource;

	 @InjectMocks
	 private JDBCStudentDAOImpl jdbcStudentDAOImpl;
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(jdbcStudentDAOImpl)
	                .build();
	    }
	@Test
	public void testUpdateStudentData_positive() {
		try {
		    when(manager.openConnection()).thenReturn(connection);   
			when(connection.prepareStatement(Mockito.anyString())).thenReturn(statement);
			when(statement.executeUpdate()).thenReturn(1);

	   Student student=new Student();
	   student.setRollNo(1011);
	   student.setStudentName("rohan");
	   student.setStudentAddress("aaa");
	   boolean actual=jdbcStudentDAOImpl.updateStudentData(student);
	   assertEquals(true,actual);
		}catch(Exception e) {
			assertTrue(false);
		}	
	}
	
	@Test
	public void testUpdateStudentData_negative() {
		try {
		    when(manager.openConnection()).thenReturn(connection);   
			when(connection.prepareStatement(Mockito.anyString())).thenReturn(statement);
			when(statement.executeUpdate()).thenReturn(0);

	   Student student=new Student();
	   student.setRollNo(69);
	   student.setStudentName("rohan");
	   student.setStudentAddress("aaa");
	   boolean actual=jdbcStudentDAOImpl.updateStudentData(student);
	   assertEquals(false,actual);
		}catch(Exception e) {
			assertTrue(false);
		}	
	}
	
	@Test
	public void testUpdateStudentData_exception() {
		try {
		    when(manager.openConnection()).thenReturn(connection);   
			when(connection.prepareStatement("update student set student_name=?,"
					+ "student_address=? where roll_no=?")).thenReturn(statement);
			when(statement.executeUpdate()).thenThrow(SQLException.class);

	   Student student=new Student();
	   student.setRollNo(69);
	   student.setStudentName("rohan");
	   student.setStudentAddress("aaa");
	   jdbcStudentDAOImpl.updateStudentData(student);
	   assertTrue(false);
		}catch(Exception e) {
			assertTrue(true);
		}	
	}

}
