package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;

import com.yash.controller.StudentController;
import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentControllerMock {
	 private MockMvc mockMvc;

	 @Mock
	 private StudentService studentService;
	 
	
	 @InjectMocks
	 private StudentController studentController;
	 
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .build();
	    }
	   
	@Test
	public void test_retieveAllStudents_positive() {
		try {
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1001);
		studentResponse.setStudentName("sabbir");
		studentResponse.setStudentAddress("abc");
		studentResponseList.add(studentResponse);
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		assertEquals(true,studentList.size()>0);
		}catch(NullPointerException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_retieveAllStudents_positive_data_test() {
		try {
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1001);
		studentResponse.setStudentName("sabbir");
		studentResponse.setStudentAddress("abc");
		studentResponseList.add(studentResponse);
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		   assertEquals(1001,studentList.get(0).getRollNo());
		}catch(IndexOutOfBoundsException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_retieveAllStudents_negative(){
		
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		when(studentService.studentRetrievalService()).thenReturn(studentResponseList);
		ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
		List<StudentResponse> studentList=response.getBody();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollNo(1);
		studentResponse.setStudentName("test");
		studentResponse.setStudentAddress("test");
	   try {
		   when(studentList.get(0).getRollNo()==(studentResponse.getRollNo()));
		   assertTrue(false);
	   }catch(IndexOutOfBoundsException e) {
		   assertTrue(true);   
	   }
	}
	@Test
	public void test_persistStudent_positive() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(22);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    
		Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");   
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(true);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void test_persistStudent_negative() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
	    Errors mock=Mockito.mock(Errors.class);
	    when(mock.hasErrors()).thenReturn(true);
	    
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("Not Registered",studentRegisteredResponse.getResponseMessage());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_persistStudent_positive_validation() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	   
		Errors mock=Mockito.mock(Errors.class);
	    when(mock.hasErrors()).thenReturn(true);
	    List<ObjectError> objectErrorList=new ArrayList<ObjectError>();
	    ObjectError objectError=new ObjectError("validation error", "student name cannot be blank");
	    objectErrorList.add(objectError);
	    when(mock.getAllErrors()).thenReturn(objectErrorList);
	    
		when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);

		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, mock);
		StudentRegisteredResponse studentRegisteredResponse=response.getBody();
		assertEquals("valiation error",studentRegisteredResponse.getResponseMessage());
		List<StudentError> studentErrorList=studentRegisteredResponse.getStudentError();
		assertEquals(true,studentErrorList.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void test_persistStudent_exception() {
		try {
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(2221);
		studentRequest.setStudentName("rachana");
		studentRequest.setStudentAddress("abcdefg");
	    Errors errors = new BeanPropertyBindingResult(studentRequest, "studentRequest");
		when(studentService.studentRegistrationService(studentRequest)).thenThrow(StudentDAOException.class);
		ResponseEntity<StudentRegisteredResponse> response=
				studentController.persistStudent(studentRequest, errors);
        assertTrue(false);
		}catch(Exception e) {
			assertTrue(true);
		}
	}
	@Test
	public void retrieveStudentByRollNo(){
		
		when(studentService.studentRetrievalServiceByRollNo(Mockito.anyInt())).thenAnswer(new Answer<StudentResponse>(){

			public StudentResponse answer(InvocationOnMock invocation) throws Throwable {
				// TODO Auto-generated method stub
			StudentResponse response=new StudentResponse();
			response.setRollNo(1001);
			response.setStudentName("xyz");
			response.setStudentAddress("abc");
			return response;
			}
			
			
		});
		
		studentController.retrieveStudentByRollNo(1001);
	
		
	}
}
