package com.yash.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.yash.custom.CustomHttpStatus;

public class StudentErrorHandler implements ResponseErrorHandler {
	
	public boolean checkStatusCode(ClientHttpResponse response) throws IOException {
		
		int statusCode=response.getStatusCode().value();
		boolean result=false;
		switch(statusCode) {

		case 400:
			               result=true;
			               break;
		default:
			result=false;
			break;
		}
		return result;
	}
	public boolean hasError(ClientHttpResponse response) throws IOException {
		// TODO Auto-generated method stub
		return checkStatusCode(response);
	}
	public void handleError(ClientHttpResponse response) throws IOException {
		// TODO Auto-generated method stub	
		System.out.println("Status Code:"+response.getStatusCode());
		
	}

}
