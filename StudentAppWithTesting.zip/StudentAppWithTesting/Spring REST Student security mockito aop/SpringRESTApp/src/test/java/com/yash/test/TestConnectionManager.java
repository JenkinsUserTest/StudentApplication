package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.integrate.ConnectionManager;
import com.yash.integrate.DataSource;


public class TestConnectionManager {

	  @InjectMocks 
	  private ConnectionManager manager;
	  
	  @Mock
	  private DataSource dataSource;
	  
	  @Mock 
	  private Connection connection;
	  @Mock 
	  private Statement statement;
	 
	  @Before
	  public void setUp() throws ClassNotFoundException, SQLException {
	    MockitoAnnotations.initMocks(this);
	  }
	@Test
	public void testOpenConnection() {
		
		try {
			when(dataSource.getDriver()).thenAnswer(
					new Answer() {

						public Object answer(InvocationOnMock invocation) throws Throwable {
							// TODO Auto-generated method stub
							return "com.mysql.jdbc.Driver";
						}
						
					}
					);
			when(dataSource.getUrl()).thenAnswer(
					new Answer() {

						public Object answer(InvocationOnMock invocation) throws Throwable {
							// TODO Auto-generated method stub
							return "jdbc:mysql://localhost:3306/test";
						}
						
					}
					);
			
			when(dataSource.getUsername()).thenAnswer(
					new Answer() {

						public Object answer(InvocationOnMock invocation) throws Throwable {
							// TODO Auto-generated method stub
							return "root";
						}
						
					}
					);
			
			when(dataSource.getPassword()).thenAnswer(
					new Answer() {

						public Object answer(InvocationOnMock invocation) throws Throwable {
							// TODO Auto-generated method stub
							return "root";
						}
						
					}
					);
			Class.forName(dataSource.getDriver());
			
		    when(connection.createStatement()).thenReturn(statement);
		    //when(connection.createStatement().executeUpdate("")).thenReturn(1);
             
		   // Assert.assertEquals(value, 1);
		    //verify(connection.createStatement(), Mockito.times(1));
		    
		}catch(Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}
}
}