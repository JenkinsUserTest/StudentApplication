package com.yash.proxy;

public class MyClass {

	
	public void then(String str) {
		System.out.println(str);
	}
	public String x(String str) {
		return str;
	}
}
