package com.yash.proxy;

import java.lang.reflect.Method;
import java.util.Arrays;

import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.CallbackFilter;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.FixedValue;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
public class CGLIBProxy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(MyClass.class);
		enhancer.setCallback( new MethodInterceptor () {

			public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
				// TODO Auto-generated method stub
				MyClass mc=(MyClass)obj;
				//mc.then("then");
				System.out.println(Arrays.toString(args));
				return "test";
			}
		} );
		MyClass proxy = (MyClass) enhancer.create();
		 
		String result = proxy.x("java");
		System.out.println("Result:"+result);
	
		
		Enhancer enhancer1 = new Enhancer();
		enhancer1.setSuperclass(MyInterface.class);
		enhancer1.setCallback( new FixedValue () {

		public Object loadObject() throws Exception {
				// TODO Auto-generated method stub
				return "sabbir";
			}
		} );
		MyInterface myInterfaceProxy = (MyInterface) enhancer1.create();
		 
		String result1 = myInterfaceProxy.y(null);
		System.out.println("Result:"+result1);

	}

}
