package com.yash.client;

import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.yash.handler.StudentErrorHandler;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;

public class PostStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestTemplate template=new RestTemplate();
		
		
		template.setErrorHandler(new StudentErrorHandler());
		
		StudentRequest studentRequest=new StudentRequest();
		studentRequest.setRollNo(109);
		studentRequest.setStudentName("");
		studentRequest.setStudentAddress("Amanora");
		
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> requestEntity=new HttpEntity<String>(headers);
		
		String url="http://localhost:8082/student-app/students";
		
		StudentRegisteredResponse response=
				template.postForObject(url, studentRequest,StudentRegisteredResponse.class);
		
		System.out.println("Message:"+response.getResponseMessage());
		List<StudentError> studentErrorList=response.getStudentError();
		
		for(StudentError studentError:studentErrorList) {
			System.out.println(studentError);
		}
	
		
		
		

	}

}
